#!/bin/bash -l
# Standard output and error:
#SBATCH -o slurm/output.txt
#SBATCH -e slurm/error.txt
# Initial working directory:
#SBATCH -D ./
# Job Name:
#SBATCH -J MgO-LDA

#SBATCH --nodes=1
#SBATCH --ntasks-per-node=72
#SBATCH --mail-type=NONE
#SBATCH --time=01:00:00

###################################################################
# Clean slurm folder
rm -rf slurm/*
mkdir -p slurm
exec >> slurm/my_output.txt 2>&1   # Optional: redirect all output

# Load modules
module purge
module load intel/2024.0 
module load impi/2021.11 
module load mkl/2024.0
export LD_LIBRARY_PATH="${MKL_HOME}/lib/intel64:${LD_LIBRARY_PATH}"
export LD_LIBRARY_PATH="${INTEL_HOME}/compiler/2022.2.1/linux/compiler/lib/intel64_lin:${LD_LIBRARY_PATH}"
export PYTHONPATH="${PYTHONPATH}:/u/elsto/programs/eslib"
conda activate eslib
source ~/programs/eslib/install.sh

# Programs and paths
export AIMS_PATH="/u/elsto/programs/FHIaims/build"
export AIMS_EXE="aims.260326.scalapack.mpi.x"

ulimit -s unlimited

#-----------------------------------#
# Functions
get_current_date_time() {
    date +"%Y-%m-%d %H:%M:%S"
}

calculate_elapsed_time() {
    start_time="$1"
    end_time="$2"
    start_seconds=$(date -d "$start_time" +%s)
    end_seconds=$(date -d "$end_time" +%s)
    elapsed_seconds=$((end_seconds - start_seconds))
    echo "$elapsed_seconds seconds"
}

run_aims(){
    echo "Running ${AIMS_OUTPUT_FILE}" >> "$LOG_FILE"
    start_time=$(get_current_date_time)
    cmd="srun ${AIMS_PATH}/${AIMS_EXE} &> aims.out"
    echo "$cmd"
    eval "$cmd"
    end_time=$(get_current_date_time)
    echo "# End Time: $end_time" >> "$LOG_FILE"
    echo "# Elapsed Time: $(calculate_elapsed_time "$start_time" "$end_time")" >> "$LOG_FILE"
    echo ""
    cp aims.out ${AIMS_OUTPUT_FILE}
    rm aims.out
}

#-----------------------------------#
cp geometry.in original.in
# Logging
LOG_FILE="log.out"
rm -f "$LOG_FILE"
echo "# Job ID: $SLURM_JOB_ID" >> "$LOG_FILE"
echo "# Date and Time: $(date +"%Y-%m-%d %H:%M:%S")" >> "$LOG_FILE"

export SOCKET_HOST="${SOCKET_HOST:-$(hostname -i | awk '{print $1}')}"
export SOCKET_PORT=$((1025 + RANDOM % (65535 - 1025 + 1)))

optimize.py  -i geometry.in -p ${SOCKET_PORT} -f 1e-6 -cs true -rc true --print-cell true > optimize.txt & 
echo "use_pimd_wrapper ${SOCKET_HOST} ${SOCKET_PORT}" > tmp.in

# optimize.py  -i geometry.in -u true -a ${SOCKET_HOST} -f 1e-4 -cs true -rc true > optimize.txt & 
# echo "use_pimd_wrapper UNIX:${SOCKET_HOST} ${SOCKET_PORT}" > tmp.in

cat tmp.in aims.in > control.in
rm tmp.in

sleep 10
AIMS_OUTPUT_FILE="scf.out"
run_aims

rm -f minimization-trajectory.pickle
rm -f minimization-trajectory.extxyz

# #-----------------------------------#

convert-file.py -i final.extxyz -o geometry.in

information-and-primitive.py -i geometry.in > symmetry.txt

cp aims.in control.in
AIMS_OUTPUT_FILE="relax.out"
run_aims
