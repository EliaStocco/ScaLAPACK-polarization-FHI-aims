from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import pandas as pd


BASE = Path(__file__).resolve().parent
DATA_FILE = BASE / "dataframe.csv"
STYLE_FILE = BASE.parent / "style.mplstyle"
OUTPUT_FILE = BASE / "comparison.pdf"

COLORS = {
    "lapack": "#1f77b4",
    "scalapack": "#ff7f0e",
}

LABELS = {
    "lapack": "LAPACK",
    "scalapack": "ScaLAPACK",
}


def load_data(path):
    dataframe = pd.read_csv(path)
    required = {"supercell", "atoms", "calculation", "method", "time"}
    missing = required - set(dataframe.columns)
    if missing:
        raise ValueError(f"Missing columns in {path}: {sorted(missing)}")

    dipole = dataframe[dataframe["calculation"] == "dipole"].rename(
        columns={"time": "dipole_time"}
    )
    scf = dataframe[dataframe["calculation"] == "scf"].rename(
        columns={"time": "scf_time"}
    )

    difference = dipole.merge(
        scf[["supercell", "atoms", "method", "scf_time"]],
        on=["supercell", "atoms", "method"],
        how="inner",
        validate="one_to_one",
    )
    difference["time_difference"] = (
        difference["dipole_time"] - difference["scf_time"]
    )
    return difference.sort_values(["method", "supercell"])


def plot(dataframe):
    fig, ax = plt.subplots(figsize=(3, 2))

    for method in ("lapack", "scalapack"):
        subset = dataframe[dataframe["method"] == method].sort_values("atoms")
        if subset.empty:
            continue

        color = COLORS[method]
        ax.plot(
            subset["atoms"],
            subset["time_difference"],
            color=color,
            linewidth=1.2,
            alpha=0.6,
        )
        ax.scatter(
            subset["atoms"],
            subset["time_difference"],
            color=color,
            label=LABELS[method],
            zorder=3,
        )

    ax.set_xscale("log", base=2)
    if (dataframe["time_difference"] > 0).all():
        ax.set_yscale("log", base=2)

    ax.set_xlabel("n. atoms")
    ax.set_ylabel("dipole time − SCF time (s)")

    xticks = sorted(dataframe["atoms"].unique())
    ax.xaxis.set_major_locator(mticker.FixedLocator(xticks))
    ax.xaxis.set_major_formatter(mticker.FormatStrFormatter("%d"))
    ax.tick_params(axis="x", which="minor", length=3)
    ax.tick_params(axis="x", which="major", length=4)

    legend = ax.legend(loc="best")
    legend.get_frame().set_facecolor("white")
    legend.get_frame().set_edgecolor("black")
    legend.get_frame().set_alpha(1.0)

    fig.tight_layout()
    return fig


def main():
    if STYLE_FILE.exists():
        plt.style.use(STYLE_FILE)

    dataframe = load_data(DATA_FILE)
    if dataframe.empty:
        raise RuntimeError("No supercell has both SCF and dipole timings")

    figure = plot(dataframe)
    figure.savefig(OUTPUT_FILE, bbox_inches="tight")
    print(f"Saved {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
