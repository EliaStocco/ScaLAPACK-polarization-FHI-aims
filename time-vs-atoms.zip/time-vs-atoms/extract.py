#!/usr/bin/env python3

import re
from pathlib import Path

import pandas as pd


TIMING_REGEX = re.compile(
    r"^\s*\|\s*Total time\s*:\s*"
    r"(?P<cpu>[\d.eE+-]+)\s*s\s+"
    r"(?P<wall>[\d.eE+-]+)\s*s\s*$",
    re.MULTILINE,
)

NUMBER_OF_ATOMS_REGEX = re.compile(
    r"^\s*\|\s*Number of atoms\s*:\s*(?P<atoms>\d+)\s*$",
    re.MULTILINE,
)


def read_aims_output(outfile):
    """Return the wall time and number of atoms from an FHI-aims output."""

    text = outfile.read_text(errors="ignore")

    timing = TIMING_REGEX.search(text)
    if timing is None:
        raise ValueError(f"Could not find total timing in {outfile}")

    atoms = NUMBER_OF_ATOMS_REGEX.search(text)
    if atoms is None:
        raise ValueError(f"Could not find number of atoms in {outfile}")

    # The second value on the Total time line is the wall-clock time,
    # matching comparison/extract.py.
    wall_time = float(timing.group("wall"))
    number_of_atoms = int(atoms.group("atoms"))
    return wall_time, number_of_atoms


def main():
    base = Path(__file__).resolve().parent
    rows = []

    supercell_dirs = sorted(
        (path for path in base.glob("supercell-*") if path.is_dir()),
        key=lambda path: int(path.name.removeprefix("supercell-")),
    )

    for supercell_dir in supercell_dirs:
        supercell = int(supercell_dir.name.removeprefix("supercell-"))

        for method in ("lapack", "scalapack"):
            for calculation in ("scf", "dipole"):
                outfile = supercell_dir / method / calculation / "aims.out"

                if not outfile.exists():
                    print(f"[WARN] Missing {outfile.relative_to(base)}")
                    continue

                try:
                    time, atoms = read_aims_output(outfile)
                except ValueError as error:
                    print(f"[WARN] {error}")
                    continue

                rows.append(
                    {
                        "supercell": supercell,
                        "atoms": atoms,
                        "calculation": calculation,
                        "method": method,
                        "time": time,
                    }
                )

                print(
                    f"supercell {supercell:>3} | "
                    f"{method:10s} | {calculation:7s} | "
                    f"{atoms:>4} atoms | {time:.3f} s"
                )

    if not rows:
        raise RuntimeError("No FHI-aims output files were found")

    dataframe = pd.DataFrame(rows).sort_values(
        ["supercell", "method", "calculation"]
    )
    output = base / "dataframe.csv"
    dataframe.to_csv(output, index=False)
    print(f"\nSaved {output}")


if __name__ == "__main__":
    main()
