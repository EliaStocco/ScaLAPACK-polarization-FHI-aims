# Corrected-polarization scaling bundle

This archive contains the non-dense-SCF-grid campaign with the polarization
direction corrected:

| Supercell | SCF k-grid | Polarization grid |
|---|---|---|
| 4x4x4 | 2x2x2 | `3 2 2 4` |
| 8x8x8 | 1x1x1 | `3 1 1 2` |

`raw/` contains the FHI-aims outputs for the available points and the matching
standalone SCF outputs.  The 8x8x8 LDA 128-core point and HSE06 256/2048-core
points are not included because they do not have completed results.  The HSE06
8x8x8 points were run from an unconverged density and should be treated as
preliminary.

Run from this directory:

```bash
python3 fit_scaling.py
```

This writes `timing_data.csv` and `scaling_summary.csv`.  The fitted convention
is `t_pol = C * N^(-p)`, so `p` is reported non-negative; `R2` is the log-log
coefficient of determination.  Here `t_pol` is the corrected-grid combined
SCF/polarization runtime minus the matching standalone SCF runtime.
