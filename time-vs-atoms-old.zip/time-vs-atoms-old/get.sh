for n in 2 3 4 6 ; do
    mkdir -p supercell-${n}
    scp viper:/u/elsto/works/ScaLAPACK-memory/MgO/supercell-${n}/lapack-1024/geometry.in supercell-${n}/geometry.in
    scp viper:/u/elsto/works/ScaLAPACK-memory/MgO/supercell-${n}/lapack-1024/aims.out supercell-${n}/lapack.out
    scp viper:/u/elsto/works/ScaLAPACK-memory/MgO/supercell-${n}/scalapack-1024/aims.out supercell-${n}/scalapack.out
done